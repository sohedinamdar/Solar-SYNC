// Solar Sync Arduino telemetry example
// Connect four LDR voltage dividers to A0-A3.
// Replace the demo orientation math with your motor encoder readings in production.

const int sensorEast = A0;
const int sensorWest = A1;
const int sensorTop = A2;
const int sensorBottom = A3;
unsigned long startedAt;
float yieldToday = 0.0;

void setup() {
  Serial.begin(115200);
  startedAt = millis();
}

void loop() {
  int east = analogRead(sensorEast);
  int west = analogRead(sensorWest);
  int top = analogRead(sensorTop);
  int bottom = analogRead(sensorBottom);

  float azimuth = constrain(135.0 + (east - west) * 0.08, 0.0, 360.0);
  float elevation = constrain(42.0 + (top - bottom) * 0.06, 0.0, 90.0);
  float power = max(0.0, (east + west + top + bottom) / 409.6);
  yieldToday += power / 360000.0; // simple demo accumulation at 10 Hz

  Serial.print("{\"azimuth\":"); Serial.print(azimuth, 1);
  Serial.print(",\"elevation\":"); Serial.print(elevation, 1);
  Serial.print(",\"power\":"); Serial.print(power, 2);
  Serial.print(",\"yieldToday\":"); Serial.print(yieldToday, 2);
  Serial.println("}");

  delay(100);
}
