---
name: solar-sync-tracker
description: Build or enhance interactive solar-tracking product experiences with Three.js, live Arduino/WebSocket telemetry, manual orientation controls, telemetry charts, and day/night lighting. Use for Solar Sync demos, solar panel dashboards, hardware-connected tracking simulations, or similar renewable-energy interfaces.
---

# Solar Sync Tracker

Create a polished solar tracking experience that combines a responsive product interface, an interactive Three.js model, and optional live hardware telemetry.

## Workflow

1. Inspect the existing page structure before editing. Preserve the brand system, existing WebSocket contract, and current demo fallback.
2. Keep the 3D scene isolated from UI logic. Use one renderer for the full-page ambient background and one renderer for the focused tracker when both are needed.
3. Use a stable telemetry object with numeric fields: `azimuth` in degrees, `elevation` in degrees, `power` in kW, and `yieldToday` in kWh. Allow extra fields without breaking the UI.
4. Maintain a demo mode when the WebSocket is unavailable. The interface must remain usable without Arduino hardware.
5. Add manual override controls with explicit state. When manual mode is active, sliders or numeric inputs must control panel orientation and prevent demo automation from overwriting the user’s values.
6. Keep a bounded telemetry history in memory. Render a lightweight chart with a canvas or SVG rather than adding a large chart dependency for a single-page demo.
7. Derive lighting from solar angle. Use elevation to interpolate between night, dawn/dusk, and day colors; update sky color, sun intensity, ambient light, and panel environment smoothly rather than abruptly.
8. Make WebSocket connection errors visible and non-blocking. Parse JSON defensively and ignore malformed messages while keeping the last valid reading.
9. Use a serial relay for USB Arduino setups. The relay should read newline-delimited JSON, broadcast the latest valid object to all browser clients, and continue running if the serial port is temporarily unavailable.
10. Validate JavaScript syntax, confirm the page has balanced script/document tags, and check responsive behavior at desktop and mobile widths.

## Recommended telemetry UI

Place the live chart beside or below the 3D simulation. Show the current azimuth, elevation, power, yield, connection state, and mode. Provide a clear `AUTO` / `MANUAL` control, azimuth and elevation sliders, and a reset-to-sun button.

## Hardware contract

The browser defaults to `ws://localhost:8765`. The relay should accept lines such as:

```json
{"azimuth":135,"elevation":42,"power":8.4,"yieldToday":34.8}
```

The Arduino may calculate orientation from LDR differentials or send actual motor encoder positions. Production hardware still needs calibration, limit switches, fault handling, and electrical/weather safety controls.

## Quality rules

Prefer readable, calm visual design over dashboard clutter. Keep interaction targets keyboard-accessible, label controls, use `requestAnimationFrame` for animation, resize renderers on viewport changes, and cap device pixel ratio for performance. Never claim live hardware is connected unless the WebSocket is open.
