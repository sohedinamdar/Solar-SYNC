# Solar Sync: Three.js + Arduino WebSocket Setup

The updated `solar-sync.html` contains an interactive Three.js tracker. Open it in a browser, drag the scene to orbit around the model, and use the **Automatic tracking** switch to pause or resume the demo movement.

## Run the live hardware bridge

Install Node.js dependencies from the folder containing the files:

```bash
cp solar-sync-package.json package.json
npm install
node solar-sync-server.js /dev/ttyUSB0 115200
```

On macOS, the port is commonly `/dev/cu.usbmodemXXXX`; on Windows, use a port such as `COM5`. The browser field defaults to `ws://localhost:8765`. Click **Connect hardware** after the relay is running.

The relay expects one JSON object per line from the Arduino:

```json
{"azimuth":135,"elevation":42,"power":8.4,"yieldToday":34.8}
```

The included `solar-sync-arduino.ino` sketch provides a minimal four-LDR example. For a production installation, replace the demo orientation calculations with readings from the actual motor encoders and add appropriate calibration, limit-switch, weather, and electrical safety handling.

The browser automatically remains in demo mode when the WebSocket is unavailable, so the 3D visualization still works without hardware.
